const Database = require('better-sqlite3');
const path = require('path');

// Guardar la DB junto al .exe, no dentro del paquete
const DB_PATH = path.join(path.dirname(process.execPath), 'ips.db');
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS ips (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ip          TEXT    NOT NULL UNIQUE,
    nombre      TEXT    DEFAULT '',
    alerta_enviada INTEGER DEFAULT 0,
    caido_desde TEXT    DEFAULT NULL,
    ultimo_check TEXT   DEFAULT NULL,
    ultimo_tiempo REAL  DEFAULT NULL
  );

  CREATE TABLE IF NOT EXISTS ping_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ip_id     INTEGER NOT NULL,
    estado    TEXT    NOT NULL,
    tiempo_ms REAL,
    fecha     TEXT    DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (ip_id) REFERENCES ips(id)
  );

  CREATE TABLE IF NOT EXISTS config (
    clave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
  );
`);

// Configuración por defecto
const DEFAULTS = {
  smtp_host:        'smtp.gmail.com',
  smtp_port:        '587',
  smtp_user:        '',
  smtp_pass:        '',
  correo_destino:   '',
  intervalo_seg:    '60',
  minutos_alerta:   '3'
};

const ins = db.prepare(`INSERT OR IGNORE INTO config (clave, valor) VALUES (?, ?)`);
for (const [k, v] of Object.entries(DEFAULTS)) ins.run(k, v);

// ── IPs ───────────────────────────────────────────────────────────────────────
function listarIPs() {
  return db.prepare(`SELECT * FROM ips ORDER BY id ASC`).all();
}

function agregarIP(ip, nombre = '') {
  try {
    db.prepare(`INSERT INTO ips (ip, nombre) VALUES (?, ?)`).run(ip.trim(), nombre.trim());
    return { ok: true };
  } catch (e) {
    return { ok: false, error: 'La IP ya existe.' };
  }
}

function editarIP(id, ip, nombre) {
  try {
    db.prepare(`UPDATE ips SET ip = ?, nombre = ? WHERE id = ?`).run(ip.trim(), nombre.trim(), id);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

function eliminarIP(id) {
  db.prepare(`DELETE FROM ping_log WHERE ip_id = ?`).run(id);
  db.prepare(`DELETE FROM ips WHERE id = ?`).run(id);
  return { ok: true };
}

// ── Estado ────────────────────────────────────────────────────────────────────
function marcarCaida(id) {
  const row = db.prepare(`SELECT caido_desde FROM ips WHERE id = ?`).get(id);
  if (!row.caido_desde) {
    db.prepare(`UPDATE ips SET caido_desde = datetime('now','localtime'), ultimo_check = datetime('now','localtime') WHERE id = ?`).run(id);
  } else {
    db.prepare(`UPDATE ips SET ultimo_check = datetime('now','localtime') WHERE id = ?`).run(id);
  }
}

function marcarAlertaEnviada(id) {
  db.prepare(`UPDATE ips SET alerta_enviada = 1 WHERE id = ?`).run(id);
}

function marcarRecuperada(id, tiempo_ms) {
  db.prepare(`
    UPDATE ips SET alerta_enviada = 0, caido_desde = NULL,
    ultimo_check = datetime('now','localtime'), ultimo_tiempo = ?
    WHERE id = ?
  `).run(tiempo_ms, id);
}

function segundosCaida(id) {
  const row = db.prepare(`SELECT caido_desde FROM ips WHERE id = ?`).get(id);
  if (!row || !row.caido_desde) return 0;
  const diff = (Date.now() - new Date(row.caido_desde + ' UTC').getTime()) / 1000;
  // Si caido_desde es hora local sin UTC, calcular así:
  const local = new Date(row.caido_desde);
  return isNaN(local) ? 0 : (Date.now() - local.getTime()) / 1000;
}

// ── Log ───────────────────────────────────────────────────────────────────────
function registrarPing(ip_id, estado, tiempo_ms) {
  db.prepare(`INSERT INTO ping_log (ip_id, estado, tiempo_ms) VALUES (?, ?, ?)`).run(ip_id, estado, tiempo_ms);
  // Mantener solo los últimos 500 registros por IP
  db.prepare(`
    DELETE FROM ping_log WHERE ip_id = ? AND id NOT IN (
      SELECT id FROM ping_log WHERE ip_id = ? ORDER BY id DESC LIMIT 500
    )
  `).run(ip_id, ip_id);
}

function historialIP(ip_id, limite = 60) {
  return db.prepare(`
    SELECT estado, tiempo_ms, fecha FROM ping_log
    WHERE ip_id = ? ORDER BY id DESC LIMIT ?
  `).all(ip_id, limite);
}

function logReciente(limite = 80) {
  return db.prepare(`
    SELECT p.estado, p.tiempo_ms, p.fecha, i.ip, i.nombre
    FROM ping_log p JOIN ips i ON p.ip_id = i.id
    ORDER BY p.id DESC LIMIT ?
  `).all(limite);
}

// ── Config ────────────────────────────────────────────────────────────────────
function getConfig(clave) {
  const r = db.prepare(`SELECT valor FROM config WHERE clave = ?`).get(clave);
  return r ? r.valor : null;
}

function setConfig(clave, valor) {
  db.prepare(`INSERT OR REPLACE INTO config (clave, valor) VALUES (?, ?)`).run(clave, valor);
}

function todaConfig() {
  return Object.fromEntries(
    db.prepare(`SELECT clave, valor FROM config`).all().map(r => [r.clave, r.valor])
  );
}

// ── Stats ─────────────────────────────────────────────────────────────────────
function stats() {
  const total   = db.prepare(`SELECT COUNT(*) c FROM ips`).get().c;
  const online  = db.prepare(`SELECT COUNT(*) c FROM ips WHERE caido_desde IS NULL`).get().c;
  const offline = total - online;
  const pingsHoy = db.prepare(`SELECT COUNT(*) c FROM ping_log WHERE fecha >= date('now','localtime')`).get().c;
  return { total, online, offline, pingsHoy };
}

module.exports = {
  listarIPs, agregarIP, editarIP, eliminarIP,
  marcarCaida, marcarAlertaEnviada, marcarRecuperada, segundosCaida,
  registrarPing, historialIP, logReciente,
  getConfig, setConfig, todaConfig,
  stats
};
