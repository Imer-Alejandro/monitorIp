/**
 * service.js
 * Registra el .exe como servicio de Windows automáticamente.
 * Solo aplica cuando se corre el ejecutable empaquetado con pkg.
 *
 * Uso:
 *   MonitorIP.exe --install    → instala el servicio y lo inicia
 *   MonitorIP.exe --uninstall  → detiene y elimina el servicio
 *   MonitorIP.exe              → corre normalmente (ya como servicio)
 */

const { execSync, exec } = require('child_process');
const path = require('path');

const SERVICE_NAME = 'MonitorIP';
const EXE_PATH = process.execPath; // ruta del .exe en ejecución

function esAdmin() {
  try {
    execSync('net session', { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

function instalarServicio() {
  if (!esAdmin()) {
    console.error('❌ Ejecuta como Administrador para instalar el servicio.');
    process.exit(1);
  }

  console.log(`📦 Instalando servicio "${SERVICE_NAME}"...`);

  try {
    // Eliminar si ya existe
    execSync(`sc stop ${SERVICE_NAME}`, { stdio: 'ignore' });
    execSync(`sc delete ${SERVICE_NAME}`, { stdio: 'ignore' });
  } catch (_) {}

  try {
    execSync(`sc create ${SERVICE_NAME} binPath= "${EXE_PATH}" start= auto DisplayName= "Monitor de IPs"`);
    execSync(`sc description ${SERVICE_NAME} "Monitorea IPs con ping y envía alertas por correo."`);
    execSync(`sc start ${SERVICE_NAME}`);
    console.log(`✅ Servicio "${SERVICE_NAME}" instalado e iniciado.`);
    console.log(`🌐 Dashboard disponible en: http://localhost:3000`);
    console.log(`\nPara desinstalar: MonitorIP.exe --uninstall`);
  } catch (e) {
    console.error('❌ Error instalando servicio:', e.message);
    process.exit(1);
  }
  process.exit(0);
}

function desinstalarServicio() {
  if (!esAdmin()) {
    console.error('❌ Ejecuta como Administrador para desinstalar el servicio.');
    process.exit(1);
  }

  console.log(`🗑️  Desinstalando servicio "${SERVICE_NAME}"...`);
  try {
    execSync(`sc stop ${SERVICE_NAME}`, { stdio: 'ignore' });
    execSync(`sc delete ${SERVICE_NAME}`);
    console.log(`✅ Servicio "${SERVICE_NAME}" eliminado.`);
  } catch (e) {
    console.error('❌ Error desinstalando:', e.message);
  }
  process.exit(0);
}

module.exports = { instalarServicio, desinstalarServicio };
